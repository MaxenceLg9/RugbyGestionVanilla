mysql -h mysql-gestionequiperugby.alwaysdata.net -u 387507 -p --default-character-set=utf8mb4

SET NAMES 'utf8mb4' COLLATE 'utf8mb4_unicode_ci';

SET character_set_client = 'utf8mb4';
SET character_set_connection = 'utf8mb4';
SET character_set_results = 'utf8mb4';


C:/Users/Maxence/Documents/Dev/PHP/Cours/Projet/PHPProjet_GestionEquipeDeSport/resources/bd.sql
C:/Users/Maxence/Documents/Dev/PHP/Cours/Projet/PHPProjet_GestionEquipeDeSport/resources/sampledata.sql